import tcpclient.TCPClient;

import java.net.*;
import java.io.*;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;

public class HTTPAsk {

    public HTTPAsk(String host, Integer port, String string, boolean shutdown, int timeout, int limit){

    }

    public HTTPAsk(){

    }

    private static void usage() {
        System.err.println("Usage: HTTPAsk [options] host port <data to server>");
        System.exit(1);
    }

    public static void main( String[] args){
        int portNumber = 0;
        try{
            portNumber = Integer.parseInt(args[0]);
        }
        catch (ArrayIndexOutOfBoundsException | NumberFormatException ex) {
            usage();
        }
        try {
            ServerSocket server = new ServerSocket(portNumber);
            while (true) {
                Socket client = server.accept();
                try {
                    String httpResponse = hRequest(client);
                    httpResponse = "HTTP/1.1 200 OK\r\n\r\n" + httpResponse;
                    OutputStream outputStream = client.getOutputStream();
                    outputStream.write(httpResponse.getBytes("UTF-8"));
                    outputStream.close();
                }catch (IOException e){
                    String httpResponse = "HTTP/1.1 400 Bad Request\r\n\r\n";
                    System.out.println("\r\n\r\n" + httpResponse);
                    OutputStream outputStream = client.getOutputStream();
                    outputStream.write(httpResponse.getBytes("UTF-8"));
                    outputStream.close();
                }
                catch (Exception e){
                    String httpResponse = "HTTP/1.1 404 Not Found\r\n\r\n";
                    System.out.println("\r\n\r\n" + httpResponse);
                    OutputStream outputStream = client.getOutputStream();
                    outputStream.write(httpResponse.getBytes("UTF-8"));
                    outputStream.close();
                }
            }
        }catch (IOException e){
            System.out.println(e);
            System.exit(1);
        }
    }

    public static String hRequest(Socket client) throws Exception {
        InputStream input = client.getInputStream();
        byte[] buffer = new byte[1024];
        int length = input.read(buffer);
        String webRequest =  new String(buffer, 0, length);
        System.out.println(webRequest);

        String[] rLines = webRequest.split("\r\n");
        String[] rLine = rLines[0].split(" ");

        String host = null;
        byte [] string = new byte[0];
        int port = 0;
        Integer timeout = null, limit = null;
        boolean shutdown = false;

        if(!rLine[0].equals("GET")){
            throw new IOException();
        }
        else if(rLine.length == 3 &&  rLine[0].equals("GET")){
            String[] webQuery = rLine[1].split("[?&]");
            if(rLine[1].startsWith("/favicon")){
                throw new Exception();
            }
            for (String wQ : webQuery) {
                String[] values = wQ.split("=");
                if (values[0].equals("hostname")) {
                    host = values[1];
                } else if (values[0].equals("port")) {
                    port = Integer.parseInt(values[1]);
                } else if (values[0].equals("string")) {
                    string = values[1].getBytes();
                } else if (values[0].equals("shutdown")) {
                    shutdown = true;
                } else if (values[0].equals("timeout")) {
                    timeout = Integer.parseInt(values[1]);
                } else if (values[0].equals("limit")) {
                    limit = Integer.parseInt(values[1]);
                }
            }
        }
        else{
            throw new Exception();
        }
        TCPClient tcpClient = new TCPClient(shutdown, timeout, limit);
        byte[] serverBytes  = tcpClient.askServer(host, port, string);
        System.out.println(new String(serverBytes));
        return new String(serverBytes);
    }

}

//System.out.println("hostname = " + host);
//System.out.println("port = " + port);
//System.out.println("string = " + new String(string));
//System.out.println("shutdown = " + shutdown);
//System.out.println("timeout = " + timeout);
//System.out.println("limit = " + limit);
